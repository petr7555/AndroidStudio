package cz.czechitas.cv4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;

/**
 * Created by skoleni on 18.04.2018.
 */

public class MainAdapter extends BaseAdapter{

    private Context context;

    public MainAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return Hawk.get("kosik", new ArrayList<String>()).size();
    }

    @Override
    public String getItem(int position) {
        return Hawk.get("kosik", new ArrayList<String>()).get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String polozka = getItem(position);
        View view = LayoutInflater.from(context).inflate(R.layout.main_list_item, null);
        TextView textView = view.findViewById(android.R.id.text1);
        textView.setText(polozka);
        return view;
    }

    public void delete(int position) {
        ArrayList<String> kosik = Hawk.get("kosik", new ArrayList<String>());
        kosik.remove(position);
        Hawk.put("kosik", kosik);
        notifyDataSetChanged();
    }
}
