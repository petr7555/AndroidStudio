package cz.czechitas.cv5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.github.kittinunf.fuel.Fuel;
import com.github.kittinunf.fuel.core.*;
import com.github.kittinunf.fuel.core.Response;
import com.google.gson.Gson;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.main_image);
        editText = findViewById(R.id.editText);
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                loadGif();
            }
        }, 0,10000);
    }

    private void loadGif() {
        // URL = https://api.giphy.com/v1/gifs/random?api_key=a5zOX3vbxlVLo04L7EBBFvS9WliFUeUg

        Fuel.get("https://api.giphy.com/v1/gifs/random?tag=" + editText.getText().toString() +"&api_key=a5zOX3vbxlVLo04L7EBBFvS9WliFUeUg")
            .responseString(new Handler<String>() {
                @Override
                public void success(Request request, Response response, String s) {
                    Gson gson = new Gson();
                    final Odpoved odpoved = gson.fromJson(s, Odpoved.class);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showGif(odpoved.data.url);
                        }
                    });

                }

                @Override
                public void failure(Request request, Response response, FuelError fuelError) {

                }
            });
    }


    private void showGif(String url) {
        Glide
                .with(this)
                .load(url)
                .asGif()
                .into(imageView);
    }

    public void onImage(View view) {
        loadGif();
    }
}
