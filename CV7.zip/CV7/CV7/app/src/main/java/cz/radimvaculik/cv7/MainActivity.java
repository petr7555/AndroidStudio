package cz.radimvaculik.cv7;

import android.Manifest;
import android.location.Address;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.OnReverseGeocodingListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.RuntimePermissions;

@RuntimePermissions
public class MainActivity extends AppCompatActivity {


    private TextView locationTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationTextView = findViewById(R.id.main_location);

        MainActivityPermissionsDispatcher.showLocationWithPermissionCheck(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        MainActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }

    @NeedsPermission(Manifest.permission.ACCESS_FINE_LOCATION)
    public void showLocation() {
        SmartLocation.with(this)
                .location()
                .config(LocationParams.NAVIGATION)
                .start(new OnLocationUpdatedListener() {
                    @Override
                    public void onLocationUpdated(Location location) {
                        //locationTextView.setText(location.getLongitude() + ", " + location.getLatitude());
                        SmartLocation.with(MainActivity.this)
                                .geocoding()
                                .reverse(location, new OnReverseGeocodingListener() {
                                    @Override
                                    public void onAddressResolved(Location location, List<Address> list) {

                                        locationTextView.setText(list.get(0).toString());
                                    }
                                });
                    }
                });
        /*Location location = SmartLocation.with(this)
                .location()
                .getLastLocation()*/
    }

    @OnPermissionDenied(Manifest.permission.ACCESS_FINE_LOCATION)
    public void OnLocationDenied() {
        Toast.makeText(this, "To je smula :(",Toast.LENGTH_LONG).show();
    }
}
