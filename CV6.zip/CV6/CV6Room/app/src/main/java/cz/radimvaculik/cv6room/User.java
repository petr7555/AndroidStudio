package cz.radimvaculik.cv6room;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public int age;
    public String hobby;

    @Override
    public String toString() {
        return id + " " + name;
    }
}
