package cz.radimvaculik.cv6room;

import android.arch.persistence.room.Room;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.main_input) EditText input;
    @BindView(R.id.main_list) ListView list;

    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        db = Room.databaseBuilder(this, AppDatabase.class, "db")
                .allowMainThreadQueries()
                .build();
        refresh();
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                User user = db.userDao().getByPosition(position);
                db.userDao().delete(user);

                refresh();
            }
        });
    }

    public void onButton(View view) {
        User user = new User();
        user.name = input.getText().toString();
        input.setText("");
        db.userDao().insert(user);

        refresh();
    }

    private void refresh() {

        List<User> users = db.userDao().getAllSorted();

        ArrayAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, users);
        list.setAdapter(adapter);
    }
}
