package cz.radimvaculik.cv6room;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

@Database(entities = {User.class}, version = 1)
abstract public class AppDatabase extends RoomDatabase {
    abstract public UserDao userDao();
}
