package cz.radimvaculik.cv6room;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
interface UserDao {
    @Query("SELECT * FROM USER")
    public List<User> getAll();

    @Query("SELECT * FROM USER ORDER BY name")
    public List<User> getAllSorted();

    @Insert
    public void insert(User user);

    @Delete
    public void delete(User user);

    @Query("SELECT * FROM user ORDER BY name LIMIT 1 OFFSET :position")
    public User getByPosition(int position);
}
