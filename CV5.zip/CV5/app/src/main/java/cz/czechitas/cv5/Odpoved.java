package cz.czechitas.cv5;

/**
 * Created by skoleni on 02.05.2018.
 */

public class Odpoved {
    public Data data;
}
