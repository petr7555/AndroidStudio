package cz.czechitas.cv5;

import com.google.gson.annotations.SerializedName;

/**
 * Created by skoleni on 02.05.2018.
 */

public class Data {
    @SerializedName("fixed_height_downsampled_url")
    public String url;
}
