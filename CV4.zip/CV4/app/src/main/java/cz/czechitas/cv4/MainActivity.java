package cz.czechitas.cv4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.orhanobut.hawk.Hawk;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText input;
    private ListView list;
    private MainAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Hawk.init(this).build();

        input = findViewById(R.id.main_input);
        list = findViewById(R.id.main_list);

        adapter = new MainAdapter(this);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                adapter.delete(position);
            }
        });

        list.setAdapter(adapter);
    }

    public void onAdd(View view) {
        String text = input.getText().toString();
        input.setText("");

        ArrayList<String> kosik = Hawk.get("kosik", new ArrayList<String>());

        if (!kosik.contains(text)) {
            kosik.add(text);
            Hawk.put("kosik", kosik);
            adapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "Jiz v kosiku!", Toast.LENGTH_LONG).show();
        }
    }

    public void onDelete(View view) {
        Hawk.delete("kosik");
        adapter.notifyDataSetChanged();

    }

}
